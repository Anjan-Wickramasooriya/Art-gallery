// assets/js/admin.js
document.addEventListener("DOMContentLoaded", function() {
    console.log("Admin side JS loaded");
});
