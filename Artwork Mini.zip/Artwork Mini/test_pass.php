<?php
mysqli_report(MYSQLI_REPORT_OFF);
$m = @new mysqli('127.0.0.1', 'root', '');
if($m->connect_error) {
    echo "127.0.0.1 Failed: " . $m->connect_error . "\n";
} else {
    echo "127.0.0.1 Success!\n";
}
