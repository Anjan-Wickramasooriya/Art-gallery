<?php 
require_once 'includes/db_connect.php';
require_once 'includes/header.php'; 
?>

<div class="container mt-4" style="padding-top: 2rem;">
    <h2 class="section-title">All Artworks</h2>
    <p style="text-align: center; margin-bottom: 2rem; color: #666;">Browse our complete collection of artworks currently available for sale.</p>
    
    <div class="artwork-grid">
        <?php
        // Fetch all available artworks
        $sql = "SELECT * FROM artworks WHERE availability = 'In Stock' ORDER BY created_at DESC";
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                // If no image, use high quality placeholder
                $imgSrc = !empty($row["image"]) ? $row["image"] : 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80';
                
                echo '<div class="artwork-card">';
                echo '  <div class="artwork-img-wrapper">';
                echo '      <img src="' . htmlspecialchars($imgSrc) . '" alt="' . htmlspecialchars($row["name"]) . '">';
                echo '  </div>';
                echo '  <div class="artwork-info">';
                echo '      <div class="artwork-category">' . htmlspecialchars($row["category"]) . '</div>';
                echo '      <h3 class="artwork-title">' . htmlspecialchars($row["name"]) . '</h3>';
                echo '      <div class="artwork-price-row">';
                echo '          <div class="artwork-price">$' . htmlspecialchars($row["price"]) . '</div>';
                echo '          <div class="artwork-rating">★ 4.8 <span>(24)</span></div>';
                echo '      </div>';
                echo '  </div>';
                echo '  <div class="card-actions">';
                echo '      <button class="btn btn-secondary">Add to Cart</button>';
                echo '      <a href="artwork_details.php?id=' . $row["id"] . '" class="btn btn-primary">Details</a>';
                echo '  </div>';
                echo '</div>';
            }
        } else {
            // Display dummy professional items if DB is empty to show the design
            for($i=1; $i<=8; $i++) {
                $images = [
                    'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    'https://images.unsplash.com/photo-1547891654-e66ed7ebb968?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    'https://images.unsplash.com/photo-1536924940846-227afb31e2a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    'https://images.unsplash.com/photo-1580136608260-4eb11f4b24fe?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    'https://images.unsplash.com/photo-1541961017774-22349e4a1262?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    'https://images.unsplash.com/photo-1513364776144-60967b0f800f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    'https://images.unsplash.com/photo-1507643179773-3e975d7ac515?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
                    'https://images.unsplash.com/photo-1551009175-8a68da93d5f9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'
                ];
                $titles = ["Abstract Harmony", "Ocean Whispers", "Urban Minimalist", "Golden Hour", "Midnight Dream", "City Lights", "Nature's Embrace", "Modern Classical"];
                
                echo '<div class="artwork-card">';
                echo '  <div class="artwork-img-wrapper">';
                echo '      <img src="' . $images[$i-1] . '" alt="Artwork">';
                echo '  </div>';
                echo '  <div class="artwork-info">';
                echo '      <div class="artwork-category">Painting</div>';
                echo '      <h3 class="artwork-title">'.$titles[$i-1].'</h3>';
                echo '      <div class="artwork-price-row">';
                echo '          <div class="artwork-price">$299.00</div>';
                echo '          <div class="artwork-rating">★ 5.0 <span>(12)</span></div>';
                echo '      </div>';
                echo '  </div>';
                echo '  <div class="card-actions">';
                echo '      <button class="btn btn-secondary">Add to Cart</button>';
                echo '      <a href="artwork_details.php?dummy=true&item=' . $i . '" class="btn btn-primary">Details</a>';
                echo '  </div>';
                echo '</div>';
            }
        }
        ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
