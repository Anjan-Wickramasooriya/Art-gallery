<?php
session_start();
require_once '../includes/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login.php");
        exit;
    }
    
    $user_id = $_SESSION['user_id'];
    $artwork_id = $_POST['artwork_id'];
    $rating = $_POST['rating'];
    $comment = trim($_POST['comment']);
    
    $stmt = $conn->prepare("INSERT INTO reviews (user_id, artwork_id, rating, comment) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $user_id, $artwork_id, $rating, $comment);
    
    if ($stmt->execute()) {
        header("Location: ../artwork_details.php?id=" . $artwork_id . "&success=review_added");
    } else {
        header("Location: ../artwork_details.php?id=" . $artwork_id . "&error=review_failed");
    }
    
    $stmt->close();
    $conn->close();
} else {
    header("Location: ../index.php");
}
?>
