<?php
session_start();
require_once '../includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action == 'customer_register') {
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', 'Customer')";
        if ($conn->query($sql) === TRUE) {
            header("Location: ../login.php");
        } else {
            $_SESSION['error'] = "Registration failed. Email might be taken.";
            header("Location: ../register.php");
        }
        exit();
    }

    if ($action == 'customer_login') {
        $email = $conn->real_escape_string($_POST['email']);
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE email='$email' AND role='Customer'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['role'] = $user['role'];
                header("Location: ../index.php");
                exit();
            }
        }
        $_SESSION['error'] = "Invalid email or password.";
        header("Location: ../login.php");
        exit();
    }

    if ($action == 'admin_login') {
        $email = $conn->real_escape_string($_POST['email']);
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE email='$email' AND role='Admin'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['admin_name'] = $user['name'];
                $_SESSION['role'] = $user['role'];
                header("Location: ../admin/index.php");
                exit();
            }
        }
        $_SESSION['error'] = "Invalid admin credentials.";
        header("Location: ../admin/login.php");
        exit();
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: ../index.php");
    exit();
}

if (isset($_GET['admin_logout'])) {
    session_destroy();
    header("Location: ../admin/login.php");
    exit();
}
?>
