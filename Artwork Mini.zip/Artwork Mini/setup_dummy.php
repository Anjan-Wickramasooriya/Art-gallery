<?php
require_once 'includes/db_connect.php';

// Insert an artwork
$stmt = $conn->prepare("INSERT INTO artworks (name, description, category, price, availability, image) VALUES (?, ?, ?, ?, ?, ?)");
$name = "Sunset Serenade";
$desc = "A beautiful abstract representation of a sunset over the ocean. Painted with vibrant colors to bring warmth and energy to any room.";
$category = "Painting";
$price = 450.00;
$avail = "In Stock";
$image = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80";
$stmt->bind_param("ssssss", $name, $desc, $category, $price, $avail, $image);
$stmt->execute();
$artwork_id = $stmt->insert_id;

// Insert a user for the review if doesn't exist
$conn->query("INSERT IGNORE INTO users (id, name, email, password, role) VALUES (2, 'Test Customer', 'customer@example.com', 'password', 'Customer')");

// Insert a review
$stmt_rev = $conn->prepare("INSERT INTO reviews (user_id, artwork_id, rating, comment) VALUES (?, ?, ?, ?)");
$user_id = 2;
$rating = 5;
$comment = "Absolutely stunning piece! The colors are even more vibrant in person. Very happy with my purchase.";
$stmt_rev->bind_param("iiis", $user_id, $artwork_id, $rating, $comment);
$stmt_rev->execute();

$rating2 = 4;
$comment2 = "Beautiful artwork, fast shipping. Looks great in my living room.";
$stmt_rev->bind_param("iiis", $user_id, $artwork_id, $rating2, $comment2);
$stmt_rev->execute();

echo "Dummy data created successfully! Artwork ID: " . $artwork_id;
?>
