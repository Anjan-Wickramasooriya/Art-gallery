<?php require_once 'includes/header.php'; ?>
<div class="container mt-2 mb-2" style="max-width: 500px;">
    <div style="background: white; padding: 2rem; border-radius: 8px; box-shadow: var(--box-shadow);">
        <h2 class="text-center mb-1">Customer Registration</h2>
        <form action="actions/auth_process.php" method="POST">
            <input type="hidden" name="action" value="customer_register">
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: .5rem;">Full Name</label>
                <input type="text" name="name" required style="width: 100%; padding: .5rem; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: .5rem;">Email</label>
                <input type="email" name="email" required style="width: 100%; padding: .5rem; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: .5rem;">Password</label>
                <input type="password" name="password" required style="width: 100%; padding: .5rem; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%;">Register</button>
        </form>
        <p class="text-center mt-1">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
