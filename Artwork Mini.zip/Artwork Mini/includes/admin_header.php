<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ArtStore</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<?php require_once '../includes/admin_sidebar.php'; ?>
<div class="main-content">
    <div class="header">
        <h2>Dashboard Overview</h2>
        <div>
            <span>🔔 (0)</span> | 
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span> |
            <a href="../actions/auth_process.php?admin_logout=true" style="color: var(--primary); text-decoration: none;">Logout</a>
        </div>
    </div>
