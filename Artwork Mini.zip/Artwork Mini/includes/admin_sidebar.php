<div class="sidebar">
    <h2>ArtAdmin</h2>
    <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="artworks.php">Artworks</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="customers.php">Customers</a></li>
        <li><a href="reviews.php">Reviews</a></li>
        <li><a href="notifications.php">Notifications</a></li>
        <li><a href="../index.php" target="_blank">View Site</a></li>
    </ul>
</div>
