<?php
// includes/db_connect.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "artwork_ecommerce";
$port = 3307;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
