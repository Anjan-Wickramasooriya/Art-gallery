<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body style="display: flex; align-items: center; justify-content: center; height: 100vh; background-color: var(--sidebar-bg);">
    <div style="background: white; padding: 2.5rem; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); width: 100%; max-width: 400px;">
        <h2 class="text-center mb-1" style="color: var(--primary-color);">Admin Dashboard</h2>
        <p class="text-center mb-2" style="color: var(--text-light);">Secure Login</p>
        <?php
        if(isset($_SESSION['error'])) {
            echo '<div style="color: red; margin-bottom: 10px; text-align: center;">'.$_SESSION['error'].'</div>';
            unset($_SESSION['error']);
        }
        ?>
        <form action="../actions/auth_process.php" method="POST">
            <input type="hidden" name="action" value="admin_login">
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: .5rem;">Email</label>
                <input type="email" name="email" required style="width: 100%; padding: .6rem; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; margin-bottom: .5rem;">Password</label>
                <input type="password" name="password" required style="width: 100%; padding: .6rem; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: .8rem;">Login to Dashboard</button>
        </form>
    </div>
</body>
</html>
