<?php require_once '../includes/admin_header.php'; ?>
<?php require_once '../includes/db_connect.php'; ?>
<div class="dashboard-cards">
    <div class="card">
        <h3>
            <?php 
            $res = $conn->query("SELECT COUNT(*) as total FROM artworks");
            echo $res->fetch_assoc()['total']; 
            ?>
        </h3>
        <p>Total Artworks</p>
    </div>
    <div class="card">
        <h3>
            <?php 
            $res = $conn->query("SELECT COUNT(*) as total FROM users WHERE role='Customer'");
            echo $res->fetch_assoc()['total']; 
            ?>
        </h3>
        <p>Total Customers</p>
    </div>
    <div class="card">
        <h3>
            <?php 
            $res = $conn->query("SELECT COUNT(*) as total FROM orders");
            echo $res->fetch_assoc()['total']; 
            ?>
        </h3>
        <p>Total Orders</p>
    </div>
    <div class="card">
        <h3>
            $<?php 
            $res = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status='Completed'");
            echo $res->fetch_assoc()['total'] ?? '0.00'; 
            ?>
        </h3>
        <p>Total Sales</p>
    </div>
</div>

<div style="margin-top: 30px; background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
    <h3>Recent Orders</h3>
    <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
        <tr style="background: #f4f4f4; text-align: left;">
            <th style="padding: 10px; border-bottom: 1px solid #ddd;">Order ID</th>
            <th style="padding: 10px; border-bottom: 1px solid #ddd;">Date</th>
            <th style="padding: 10px; border-bottom: 1px solid #ddd;">Amount</th>
            <th style="padding: 10px; border-bottom: 1px solid #ddd;">Status</th>
        </tr>
        <?php
        $res = $conn->query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 5");
        while($row = $res->fetch_assoc()) {
            echo "<tr>";
            echo "<td style='padding: 10px; border-bottom: 1px solid #eee;'>#" . $row['id'] . "</td>";
            echo "<td style='padding: 10px; border-bottom: 1px solid #eee;'>" . date('Y-m-d', strtotime($row['created_at'])) . "</td>";
            echo "<td style='padding: 10px; border-bottom: 1px solid #eee;'>$" . $row['total_amount'] . "</td>";
            echo "<td style='padding: 10px; border-bottom: 1px solid #eee;'>" . $row['status'] . "</td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>
</div>
<script src="../assets/js/admin.js"></script>
</body>
</html>
