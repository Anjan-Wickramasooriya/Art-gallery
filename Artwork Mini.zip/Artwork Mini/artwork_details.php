<?php 
require_once 'includes/db_connect.php';
require_once 'includes/header.php'; 

$is_dummy = isset($_GET['dummy']) && $_GET['dummy'] == 'true';

if (!$is_dummy && (!isset($_GET['id']) || !is_numeric($_GET['id']))) {
    echo "<div class='container mt-4'><h2 class='section-title'>Artwork not found.</h2></div>";
    require_once 'includes/footer.php';
    exit;
}

if ($is_dummy) {
    $item_id = isset($_GET['item']) ? intval($_GET['item']) : 1;
    $idx = ($item_id - 1) % 8;
    
    $images = [
        'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1547891654-e66ed7ebb968?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1536924940846-227afb31e2a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1580136608260-4eb11f4b24fe?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1541961017774-22349e4a1262?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1513364776144-60967b0f800f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1507643179773-3e975d7ac515?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1551009175-8a68da93d5f9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ];
    $titles = ["Abstract Harmony", "Ocean Whispers", "Urban Minimalist", "Golden Hour", "Midnight Dream", "City Lights", "Nature's Embrace", "Modern Classical"];
    
    $artwork_id = 0;
    $artwork = [
        'id' => 0,
        'name' => $titles[$idx],
        'category' => 'Painting',
        'price' => '299.00',
        'description' => 'An exquisite piece of art showcasing exceptional technique and emotion. Perfect for adding a touch of elegance to any space. The vibrant colors bring warmth and energy to any room.',
        'image' => $images[$idx]
    ];
    $imgSrc = $artwork['image'];
    $reviews = [
        ['name' => 'John Doe', 'rating' => 5, 'comment' => 'Absolutely stunning piece! The colors are even more vibrant in person. Very happy with my purchase.', 'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))],
        ['name' => 'Jane Smith', 'rating' => 4, 'comment' => 'Beautiful artwork, fast shipping. Looks great in my living room.', 'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))]
    ];
    $average_rating = 4.5;
} else {
    $artwork_id = $_GET['id'];

    // Fetch artwork
    $stmt = $conn->prepare("SELECT * FROM artworks WHERE id = ?");
    $stmt->bind_param("i", $artwork_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo "<div class='container mt-4'><h2 class='section-title'>Artwork not found.</h2></div>";
        require_once 'includes/footer.php';
        exit;
    }

    $artwork = $result->fetch_assoc();
    $imgSrc = !empty($artwork["image"]) ? $artwork["image"] : 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';

    // Fetch reviews
    $review_stmt = $conn->prepare("SELECT r.*, u.name FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.artwork_id = ? ORDER BY r.created_at DESC");
    $review_stmt->bind_param("i", $artwork_id);
    $review_stmt->execute();
    $reviews_result = $review_stmt->get_result();
    $reviews = [];
    $total_rating = 0;
    while ($row = $reviews_result->fetch_assoc()) {
        $reviews[] = $row;
        $total_rating += $row['rating'];
    }
    $average_rating = count($reviews) > 0 ? round($total_rating / count($reviews), 1) : 0;
}
?>

<div class="container mt-4" style="padding-top: 2rem;">
    <div class="artwork-details-container" style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem;">
        
        <div class="artwork-image-section">
            <div style="position: sticky; top: 100px;">
                <img src="<?php echo htmlspecialchars($imgSrc); ?>" alt="<?php echo htmlspecialchars($artwork['name']); ?>" style="width: 100%; border-radius: var(--radius-lg); box-shadow: var(--box-shadow-lg);">
            </div>
        </div>
        
        <div class="artwork-info-section">
            <div class="artwork-category" style="font-size: 1rem; margin-bottom: 1rem; display: inline-block; padding: 0.3rem 1rem; background: rgba(245, 158, 11, 0.1); border-radius: 2rem; color: var(--secondary-color); font-weight: 600;">
                <?php echo htmlspecialchars($artwork['category']); ?>
            </div>
            <h1 style="font-size: 3rem; margin-bottom: 1rem; color: var(--primary-color); font-weight: 800; line-height: 1.1;"><?php echo htmlspecialchars($artwork['name']); ?></h1>
            <div class="artwork-price" style="font-size: 2.5rem; font-weight: bold; color: var(--secondary-color); margin-bottom: 2rem;">$<?php echo htmlspecialchars($artwork['price']); ?></div>
            
            <div style="background: white; padding: 2rem; border-radius: var(--radius-lg); box-shadow: var(--box-shadow-sm); border: 1px solid var(--border-color); margin-bottom: 2rem;">
                <h3 style="margin-bottom: 1rem; font-size: 1.2rem; color: var(--primary-color);">Description</h3>
                <p style="color: var(--text-light); font-size: 1.1rem; line-height: 1.8;">
                    <?php echo nl2br(htmlspecialchars($artwork['description'] ?? 'An exquisite piece of art showcasing exceptional technique and emotion. Perfect for adding a touch of elegance to any space.')); ?>
                </p>
            </div>
            
            <div class="actions" style="margin-bottom: 3rem; background: white; padding: 2rem; border-radius: var(--radius-lg); box-shadow: var(--box-shadow-sm); border: 1px solid var(--border-color);">
                <form action="actions/add_to_cart.php" method="POST" style="display: flex; gap: 1rem;">
                    <input type="hidden" name="artwork_id" value="<?php echo $artwork['id']; ?>">
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <label style="font-size: 0.9rem; font-weight: 600; color: var(--text-light);">Quantity</label>
                        <input type="number" name="quantity" value="1" min="1" style="width: 100px; padding: 1rem; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 1.1rem; text-align: center;">
                    </div>
                    <button type="submit" class="btn btn-primary" style="flex: 1; font-size: 1.2rem; margin-top: 1.7rem; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <ion-icon name="cart-outline" style="font-size: 1.5rem;"></ion-icon> Add to Cart
                    </button>
                </form>
            </div>

            <!-- Reviews Section right next to the image/in the info column -->
            <div class="reviews-section" id="reviews" style="background: white; border: 1px solid var(--border-color); border-radius: var(--radius-lg); padding: 2.5rem; box-shadow: var(--box-shadow-md);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color);">
                    <h3 style="font-size: 1.8rem; margin: 0; font-weight: 700;">Customer Reviews</h3>
                    <div class="average-rating" style="display: flex; align-items: center; gap: 0.5rem; color: var(--secondary-color); font-weight: bold; font-size: 1.4rem;">
                        ★ <?php echo $average_rating > 0 ? $average_rating : 'New'; ?> 
                        <span style="color: var(--text-light); font-size: 1rem; font-weight: normal;">(<?php echo count($reviews); ?> reviews)</span>
                    </div>
                </div>

                <div class="reviews-list" style="max-height: 500px; overflow-y: auto; padding-right: 1rem; margin-bottom: 2rem;">
                    <?php if (count($reviews) > 0): ?>
                        <?php foreach ($reviews as $review): ?>
                            <div class="review-item" style="background: var(--background-light); padding: 1.5rem; border-radius: var(--radius-md); margin-bottom: 1rem; border: 1px solid var(--border-color);">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 40px; height: 40px; background: var(--primary-color); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 1.2rem;">
                                            <?php echo strtoupper(substr($review['name'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <strong style="color: var(--primary-color); display: block; font-size: 1.1rem;"><?php echo htmlspecialchars($review['name']); ?></strong>
                                            <div style="font-size: 0.8rem; color: #9ca3af; margin-top: 2px;">
                                                <?php echo date('M d, Y', strtotime($review['created_at'])); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <span style="color: var(--secondary-color); font-size: 1.2rem; letter-spacing: 2px;">
                                        <?php echo str_repeat('★', $review['rating']) . str_repeat('☆', 5 - $review['rating']); ?>
                                    </span>
                                </div>
                                <p style="color: var(--text-dark); font-size: 1.05rem; line-height: 1.6; margin: 0; padding-left: 50px;">
                                    <?php echo nl2br(htmlspecialchars($review['comment'])); ?>
                                </p>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="text-align: center; padding: 3rem 0; background: var(--background-light); border-radius: var(--radius-md);">
                            <ion-icon name="chatbubbles-outline" style="font-size: 3rem; color: #d1d5db; margin-bottom: 1rem;"></ion-icon>
                            <p style="color: var(--text-light); font-size: 1.1rem;">No reviews yet. Be the first to review this artwork!</p>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="add-review-form" style="background: var(--background-light); padding: 2rem; border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                        <h4 style="margin-bottom: 1.5rem; font-size: 1.3rem; color: var(--primary-color); display: flex; align-items: center; gap: 10px;">
                            <ion-icon name="create-outline"></ion-icon> Write a Review
                        </h4>
                        <form action="actions/submit_review.php" method="POST">
                            <input type="hidden" name="artwork_id" value="<?php echo $artwork['id']; ?>">
                            <div style="margin-bottom: 1.5rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--primary-color);">Your Rating</label>
                                <select name="rating" required style="width: 100%; padding: 1rem; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 1rem; background: white; cursor: pointer;">
                                    <option value="5">★★★★★ (5/5) - Excellent</option>
                                    <option value="4">★★★★☆ (4/5) - Very Good</option>
                                    <option value="3">★★★☆☆ (3/5) - Good</option>
                                    <option value="2">★★☆☆☆ (2/5) - Fair</option>
                                    <option value="1">★☆☆☆☆ (1/5) - Poor</option>
                                </select>
                            </div>
                            <div style="margin-bottom: 1.5rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: var(--primary-color);">Your Review</label>
                                <textarea name="comment" rows="4" placeholder="What did you like about this artwork? Share your thoughts..." required style="width: 100%; padding: 1rem; border: 1px solid var(--border-color); border-radius: var(--radius-md); resize: vertical; font-size: 1rem; font-family: inherit;"></textarea>
                            </div>
                            <button type="submit" class="btn btn-secondary" style="width: 100%; font-size: 1.1rem; padding: 1rem;">Post Review</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; padding: 2rem; background: var(--background-light); border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                        <p style="color: var(--text-dark); margin-bottom: 1.5rem; font-size: 1.1rem;">Want to share your thoughts on this artwork?</p>
                        <a href="login.php" class="btn btn-primary" style="padding: 0.8rem 2rem; font-size: 1.1rem;">Sign in to Write a Review</a>
                    </div>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
</div>

<style>
@media (max-width: 900px) {
    .artwork-details-container {
        grid-template-columns: 1fr !important;
        gap: 2rem !important;
    }
    .artwork-image-section > div {
        position: static !important;
    }
}
/* Custom scrollbar for reviews list */
.reviews-list::-webkit-scrollbar {
    width: 6px;
}
.reviews-list::-webkit-scrollbar-track {
    background: #f1f1f1; 
    border-radius: 10px;
}
.reviews-list::-webkit-scrollbar-thumb {
    background: #c1c1c1; 
    border-radius: 10px;
}
.reviews-list::-webkit-scrollbar-thumb:hover {
    background: #a8a8a8; 
}
</style>

<?php require_once 'includes/footer.php'; ?>
